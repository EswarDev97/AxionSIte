@include('mails.layouts.header')

<div class="mail-area">
    @yield('mail-body')
</div>

@include('mails.layouts.footer')